const d1=document.getElementById("d1");
const d2=document.getElementById("d2");
const d3=document.getElementById("d3");
const d4=document.getElementById("d4");
const d5=document.getElementById("d5");
const c1=document.getElementById("c1");
const c2=document.getElementById("c2");
const c3=document.getElementById("c3");
const c4=document.getElementById("c4");
const c5=document.getElementById("c5");
var x1=0,x2=0,x3=0,x4=0,x5=0
d1.addEventListener("click",()=>{
    if(x1==0)
    {
    c1.style.display="block";
    c1.style.width="100%";
    d1.style.transform="rotate(270deg)"
    d1.style.transition="1s"
    c1.transition="1s"
    x1=1
    }
    else{
        c1.style.display="none";
        d1.style.transform="rotate(90deg)";
        c1.style.width="0";
        x1=0
    }
})
d2.addEventListener("click",()=>{
    if(x2==0)
    {
    c2.style.display="block";
    c2.style.width="100%";
    d2.style.transform="rotate(270deg)"
    d2.style.transition="1s"
    c2.transition="1s"
    x2=1
    }
    else{
        c2.style.display="none";
        d2.style.transform="rotate(90deg)";
        c2.style.width="0";
        x2=0
    }
});
 d3.addEventListener("click",()=>{
    if(x3==0)
    {
    c3.style.display="block";
    c3.style.width="100%";
    d3.style.transform="rotate(270deg)"
    d3.style.transition="1s"
    c3.transition="1s"
    x3=1
    }
    else{
        c3.style.display="none";
        d3.style.transform="rotate(90deg)";
        c3.style.width="0";
        x3=0
    }
});

d4.addEventListener("click",()=>{
    if(x4==0)
        {
        c4.style.display="block";
        c4.style.width="100%";
        d4.style.transform="rotate(270deg)"
        d4.style.transition="1s"
        c4.transition="1s"
        x4=1
        }
    else{
        c4.style.display="none";
        d4.style.transform="rotate(90deg)";
        c4.style.width="0";
        x4=0
    }
})
d5.addEventListener("click",()=>{
    if(x5==0)
    {
    c5.style.display="block";
    c5.style.width="100%";
    d5.style.transform="rotate(270deg)"
    d5.style.transition="1s"
    c5.transition="1s"
    x5=1
    }
    else{
        c5.style.display="none";
        d5.style.transform="rotate(90deg)";
        c5.style.width="0";
        x5=0
    }
});

// -------------------------------------------------------------------------
const abtH=document.getElementById("abtH");
const commonInp=document.getElementById("commonInp");
const start=document.getElementById("start");
const fot=document.getElementById("fot");
start.addEventListener("click",()=>{
    commonInp.style.display="flex";
    abtH.style.display="none";
    fot.style.display="none";
})

const next=document.getElementById("next");
const p33=document.getElementById("p33");
const p11=document.getElementById("p11");
const p22=document.getElementById("p22");

const getin=document.getElementById("getin");
next.addEventListener("click",()=>{
    p33.style.display="flex";
  
    p33.style.transition="0.8s"
    p11.style.display="none";
    p22.style.animation="move 0.8s"
    console.log(getin.value)
})

const Life = document.getElementById('Life');
const TermLife = document.getElementById('TermLife');
const Renters = document.getElementById('Renters');  // Ensure this option is in your HTML now
const PersonalAccident = document.getElementById('PersonalAccident');
const CriticalIllness = document.getElementById('CriticalIllness');
const ChildEducation = document.getElementById('ChildEducation');
const IncomeProtection = document.getElementById('IncomeProtection');
const FamilyFloaterHealth = document.getElementById('FamilyFloaterHealth');
const Retirement = document.getElementById('Retirement');  // Ensure this option is in your HTML now
const TwoWheeler = document.getElementById('TwoWheeler');  // Ensure this option is in your HTML now
const Pet = document.getElementById('Pet');
const Health = document.getElementById('Health');
const Automobile = document.getElementById('Automobile');
const Agriculture = document.getElementById('Agriculture');
const Marine = document.getElementById('Marine');
const WorkmenCompensation = document.getElementById('WorkmenCompensation');  // Ensure this option is in your HTML now
const Cyber = document.getElementById('Cyber');
const Travel = document.getElementById('Travel');


const insuranceSections = [
    "Life", "TermLife", "Renters", "PersonalAccident", "CriticalIllness",
    "ChildEducation", "IncomeProtection", "FamilyFloaterHealth", 
    "TwoWheeler", "Pet", "Health", "Automobile", "Agriculture", "Marine",
    "WorkmenCompensation", "Cyber"
];
var r="Retirement",t="Travel"
// Event listener for the dropdown change
getin.addEventListener('change', function() {
    const selectedInsurance = this.value; // Get the selected insurance type

    // Hide all insurance sections
    insuranceSections.forEach((sectionId) => {
        const section = document.getElementById(sectionId);
        if (section) {
            section.style.display = 'none';
        }
    });

    // Show the selected insurance section
    const selectedSection = document.getElementById(selectedInsurance);
    if (selectedSection) {
        selectedSection.style.display = 'block';
    }
});